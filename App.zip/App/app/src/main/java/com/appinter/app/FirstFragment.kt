package com.appinter.app

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.appinter.app.databinding.FragmentFirstBinding
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.*

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null
    var Water = MainActivity()
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.buttonSelection.setOnClickListener {
            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }

        binding.buttonBluetooth.setOnClickListener {
            findNavController().navigate(R.id.action_FirstFragment_to_bluetoothFragment)
        }

        binding.buttonStatistics.setOnClickListener {
            fun timeLog() {
                val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
                val currentDate = sdf.format(Date())
                System.out.println(" C DATE is  $currentDate")
            }
            fun logging() {
                // content to be written to file
                var content: String = "string"
                when(Water.amountWater){
                    0 -> content = ("watered watered none")
                    25 -> content = ("watered little")
                    50 -> content = ("watered moderately")
                    75 -> content = ("watered a fair amount")
                    100 -> content = ("watered a lot")
                }

                // using java class java.io.PrintWriter
                val writer = PrintWriter("file.txt")
                writer.append(content)
                writer.close()
                timeLog()
            }
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}